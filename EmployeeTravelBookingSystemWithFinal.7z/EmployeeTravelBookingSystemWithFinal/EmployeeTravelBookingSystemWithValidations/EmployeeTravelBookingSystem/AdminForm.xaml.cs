﻿using EmployeeTravelBookingSystem.BussinessLayer;
using EmployeeTravelBookingSystem.Exception;
using Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeTravelBookingSystem
{
    /// <summary>
    /// Interaction logic for AdminForm.xaml
    /// </summary>
    public partial class AdminForm : Window
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            CanvasMakeManager.Visibility = Visibility.Hidden;
            CanvasAddTravelAgent.Visibility = Visibility.Hidden;
            CanvasAssignManager.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            CanvasMakeManager.Visibility = Visibility.Hidden;
            CanvasAddTravelAgent.Visibility = Visibility.Hidden;
            CanvasAssignManager.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Visible;

            
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            CanvasMakeManager.Visibility = Visibility.Hidden;
            CanvasAddTravelAgent.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Hidden;
            CanvasAssignManager.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            CanvasMakeManager.Visibility = Visibility.Hidden;
            CanvasAssignManager.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Hidden;
            CanvasAddTravelAgent.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {

        }

        //Adding Employee
        private void BtnAddEmployee_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string gender;

                if (txtAddEmployeeEmpId.Text == "")
                {
                    lblEmpid.Content = "Enter Employee Id";
                    txtAddEmployeeFname.Focus();
                    return;
                }
                lblEmpid.Content = null;

                if (txtAddEmployeeFname.Text == "")
                {
                    lblEmpFname.Content = "Enter First Name";
                    txtAddEmployeeFname.Focus();
                    return;
                }
                lblEmpFname.Content = null;

                if (txtAddEmployeeLname.Text == "")
                {
                    lblLName.Content = "Enter Last NAme";
                    txtAddEmployeeFname.Focus();
                    return;
                }
                lblLName.Content = null;

                if (txtAddEmployeeAge.Text == "" || (int.Parse(txtAddEmployeeAge.Text)<18 || int.Parse(txtAddEmployeeAge.Text) > 61))
                {
                    lblAge.Content = "enter Age between 18 to 60";
                    txtAddEmployeeFname.Focus();
                    return;
                }
                lblAge.Content = null;

                if (txtEmployeeAddress.Text == "")
                {
                    lblAddress.Content = "Enter Address";
                    txtAddEmployeeFname.Focus();
                    return;
                }
                lblAddress.Content = null;

                if (txtEmployeeEmailId.Text == "")
                {
                    lblEmail.Content = "Enter Email Id";
                    txtAddEmployeeFname.Focus();
                    return;
                }
                lblEmail.Content = null;

                if (txtAddEmployeeUserId.Text == "")
                {
                    lblUserName.Content = "Enter Username";
                    txtAddEmployeeFname.Focus();
                    return;
                }
                lblUserName.Content = null;

                if (txtAddEmployeePassword.Text == "")
                {
                    lblPass.Content = "Enter Password";
                    txtAddEmployeeFname.Focus();
                    return;
                }
                lblPass.Content = null;

                if (comboBoxForManager.SelectedValue==null)
                {
                    lblManager.Content = "Select Manager";
                    txtAddEmployeeFname.Focus();
                    return;
                }
                lblManager.Content = null;

                if (rbtnAddEmployeeMale.IsChecked == true)
                {
                    gender = "Male";
                }
                else
                {
                    gender = "Female";
                }
                EmployeeDetails details = new EmployeeDetails()
                {
                    EmployeeId = int.Parse(txtAddEmployeeEmpId.Text),
                    FirstName = txtAddEmployeeFname.Text,
                    LastName = txtAddEmployeeLname.Text,
                    Age = int.Parse(txtAddEmployeeAge.Text),
                    Gender = gender,
                    Address = txtEmployeeAddress.Text,
                    MobileNumber = txtEmployeeMobilenumber.Text,
                    EmailId = txtEmployeeEmailId.Text,
                    UserName = txtAddEmployeeUserId.Text,
                    Password = txtAddEmployeePassword.Text,
                    ManagerId = int.Parse(comboBoxForManager.SelectedValue.ToString())


                };
                BookingBL bbl = new BookingBL();
                bool employeeAdded = bbl.AddEmployee(details);
                if (employeeAdded)
                {
                    MessageBox.Show("Employee Added");
                    txtAddEmployeeEmpId.Text = "";
                    txtAddEmployeeFname.Text = "";
                    txtAddEmployeeLname.Text = "";
                    txtAddEmployeeAge.Text = "";
                    txtEmployeeAddress.Text = "";
                    txtEmployeeMobilenumber.Text = "";
                    txtEmployeeEmailId.Text = "";
                    txtAddEmployeeUserId.Text = "";
                    txtAddEmployeePassword.Text = "";


                }
                else
                {
                    MessageBox.Show("Employee details are not correct");
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
           
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
       

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {

                BookingBL pb = new BookingBL();
                DataTable dt = pb.GetMangerListBL();

                if (dt != null)
                {
                    comboBoxForManager.ItemsSource = dt.AsDataView();

                    comboBoxForManager.DisplayMemberPath = "ManagerName";
                    comboBoxForManager.SelectedValuePath = "ManagerId";

                }
                else
                {
                    MessageBox.Show("Table is empty");
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        
        private void CanvasAddEmployee_Loaded(object sender, RoutedEventArgs e)
        {
           
        }


        //Delete Employee
        private void BtnDeleteEmployee_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                int delemp = int.Parse(txtDeleteEmployeeId.Text);
                BookingBL bbl = new BookingBL();
                bool deleteEmployee = bbl.DeleteEmployee(delemp);
                if (deleteEmployee)
                {
                    MessageBox.Show("employee deleted");
                    txtDeleteEmployeeId.Text = "";
                }
                else
                {
                    MessageBox.Show("Employee Not Found");
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
          
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //change Manager
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                EmployeeDetails details = new EmployeeDetails()
                {
                    EmployeeId = Convert.ToInt32(txtEmployeeIdForAssigningManager.Text),
                    ManagerId = int.Parse(cbAssignMangerName.SelectedValue.ToString())
                };


                BookingBL bbl = new BookingBL();
                bool Assigned = bbl.UpdateManager(details);
                if (Assigned)
                {
                    MessageBox.Show("Manager Assigned");
                    txtEmployeeIdForAssigningManager.Text = "";
                }
                else
                {
                    MessageBox.Show("Employee not found");
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
           
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Generation of Manager List
        private void CanvasAssignManager_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {

                BookingBL pb = new BookingBL();
                DataTable dt = pb.GetMangerListBL();
                

                if (dt != null)
                {
                    
                    cbAssignMangerName.ItemsSource = dt.DefaultView;
                    cbAssignMangerName.DisplayMemberPath = "ManagerName";
                    cbAssignMangerName.SelectedValuePath = "ManagerId";
                }
                else
                {
                    MessageBox.Show("No requests are made by employees");
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        //Adding Agent 
        private void BtnAddAgent_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtAddAgentName.Text == "")
                {
                    lblAgentname.Content = "Enter Agent Name";
                    txtAddEmployeeFname.Focus();
                    return;
                }
                lblAgentname.Content = null;

                if (txtAddAgentUserName.Text == "")
                {
                    lblagentUser.Content = "Enter Agent Username";
                    txtAddEmployeeFname.Focus();
                    return;
                }
                lblagentUser.Content = null;

                if (txtAddAgentPass.Text == "")
                {
                    lblagentPAss.Content = "Enter Password";
                    txtAddEmployeeFname.Focus();
                    return;
                }
                lblagentPAss.Content = null;


                TravelAgentDetails agentDetails = new TravelAgentDetails()
                {
                    agentName = txtAddAgentName.Text,
                    agentUsername = txtAddAgentUserName.Text,
                    agentPassword = txtAddAgentPass.Text

                };

                BookingBL agent = new BookingBL();
                bool addAgent = agent.AddAgent(agentDetails);
                if (addAgent)
                {
                    MessageBox.Show("Agent Added");
                    txtAddAgentName.Text = "";
                    txtAddAgentUserName.Text = "";
                    txtAddAgentPass.Text = "";
                }
                else
                {
                    MessageBox.Show("Agent not Added");
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
           
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void MenuItem_Click_5(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void MenuItem_Click_6(object sender, RoutedEventArgs e)
        {
            CanvasAddTravelAgent.Visibility = Visibility.Hidden;
            CanvasAssignManager.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Hidden;
            CanvasMakeManager.Visibility = Visibility.Visible;
            try
            {

                BookingBL pb = new BookingBL();
                DataTable dt = pb.GetEmployeeListBL();
                if (dt != null)
                {
                    cmbEmplIst.ItemsSource = dt.DefaultView;
                    cmbEmplIst.DisplayMemberPath = "EmployeeId";
                    cmbEmplIst.SelectedValuePath = "EmployeeId";
                }
                else
                {
                    MessageBox.Show("No requests are made by employees");
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            int EmpId = int.Parse(cmbEmplIst.SelectedValue.ToString());
            BookingBL bbl = new BookingBL();
            bool newManager = bbl.MakeManagerBL(EmpId);
            if (newManager)
            {
                
                    MessageBox.Show("New Manager Added");
                
            }
            else
            {
                MessageBox.Show("Unable to make Manager");
            }

            

        }

        //Make Employee as Manager
        private void MakeManagerCanvas_Loaded(object sender, RoutedEventArgs e)
        {
            
        }

        private void btnAdmLogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void txtEmployeeMobilenumber_KeyDown(object sender, KeyEventArgs e)
        {

        }
    }
    
}
