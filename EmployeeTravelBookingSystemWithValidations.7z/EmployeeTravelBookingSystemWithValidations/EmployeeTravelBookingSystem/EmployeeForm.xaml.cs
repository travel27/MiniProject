﻿using EmployeeTravelBookingSystem.BussinessLayer;
using EmployeeTravelBookingSystem.Exception;
using Entity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeTravelBookingSystem
{
    /// <summary>
    /// Interaction logic for EmployeeForm.xaml
    /// </summary>
    public partial class EmployeeForm : Window
    {

        private string user;
        private string pass;

        string Source;
        string destination;

        public EmployeeForm()
        {
            InitializeComponent();
        }

        public EmployeeForm(string user, string pass)
        {
            this.user = user;
            this.pass = pass;
            InitializeComponent();
        }
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            CanvasCancelRequest.Visibility = Visibility.Hidden;
            CanvasDisplayRequest.Visibility = Visibility.Hidden;
            CanvasTicketBook.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            CanvasTicketBook.Visibility = Visibility.Hidden;
            CanvasDisplayRequest.Visibility = Visibility.Hidden;
            CanvasCancelRequest.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            CanvasTicketBook.Visibility = Visibility.Hidden;
            CanvasCancelRequest.Visibility = Visibility.Hidden;
            CanvasDisplayRequest.Visibility = Visibility.Visible;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           

            try
            {

                    TravelRequest raiseTicket = new TravelRequest()
                    {

                        RequestDate = DateTime.Parse(dtTicketBook.Text),
                        FromLocation = cbTicketBookFromLocation.SelectedValue.ToString(),
                        ToLocation = cbTicketBookTolocation.SelectedValue.ToString(),
                        EmployeeId = int.Parse(txtTicketBookEmpId.Text),
                        ManagerId = int.Parse(txtTicketBookManagId.Text)
                    };

                

               
                    BookingBL bookTicket = new BookingBL();
                bool bTicket = bookTicket.AddTicketRequest(raiseTicket);
                if (bTicket)
                    {
                    
                        MessageBox.Show("Ticket request raised");


                    }
                    else
                    {
                        MessageBox.Show("Select two different locations");
                    }
                
                

                

                  
            }
            catch (EmployeeTravelBookingException  )
            {
                MessageBox.Show("Select All the Fields"); 

            }
            catch (SystemException )
            {
               
                MessageBox.Show("Select All the Fields");
            }
        }




        private void CanvasTicketBook_Loaded(object sender, RoutedEventArgs e)
        {

            try
            {
                string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "mini.getdetails";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", user);
                cmd.Parameters.AddWithValue("@password", pass);

                SqlParameter empid = new SqlParameter("@EmployeeId", SqlDbType.Int) { Direction = ParameterDirection.Output };
                cmd.Parameters.Add(empid);
                SqlParameter managerId = new SqlParameter("@managerid", SqlDbType.Int) { Direction = ParameterDirection.Output };
                cmd.Parameters.Add(managerId);

                con.Open();

                SqlDataReader sd = cmd.ExecuteReader();

                txtTicketBookEmpId.Text = empid.Value.ToString();
                txtTicketBookManagId.Text = managerId.Value.ToString();
                con.Close();
                foreach (var item in Enum.GetValues(typeof(FromLocation)))
                {
                    cbTicketBookFromLocation.Items.Add(item);
                }
                foreach (var item in Enum.GetValues(typeof(ToLocation)))
                {
                    cbTicketBookTolocation.Items.Add(item);
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
          
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtnCancelTicket_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int requestid = int.Parse(txtCancelTicketReqId.Text);
                BookingBL cancelRequest = new BookingBL();
                bool CancelTicketRequest = cancelRequest.CancelticketBL(requestid);

                if (CancelTicketRequest)
                {
                    MessageBox.Show("Ticket Cancelled Successfully");
                    txtCancelTicketReqId.Text = " ";
                }
                else
                {
                    MessageBox.Show("Unable to Cancel Ticket!!! Try Again Later");
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
           
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void CanvasDisplayRequest_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button1_Click_1(object sender, RoutedEventArgs e)
        {

            try
            {
                int eid = int.Parse(txtTicketBookEmpId.Text);
                TravelRequest display = new TravelRequest();
                BookingBL requestDisplay = new BookingBL();
                DataTable dt = requestDisplay.DisplayEmpRequestBL(eid);
                if (dt != null)
                {
                    dgDisplay.ItemsSource = dt.DefaultView;
                }
                else
                {
                    MessageBox.Show("Table is empty");
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
    enum FromLocation
    {
        Hyderabad,Chennai,Pune,Bangalore,Mumbai,Delhi,Kolkata
    }
    enum ToLocation
    {
        Hyderabad, Chennai, Pune, Bangalore, Mumbai, Delhi, Kolkata
    }
}
