﻿using EmployeeTravelBookingSystem.BussinessLayer;
using EmployeeTravelBookingSystem.Exception;
using Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeTravelBookingSystem
{
    /// <summary>
    /// Interaction logic for TravelAgent.xaml
    /// </summary>
    public partial class TravelAgent : Window
    {
        public TravelAgent()
        {
            InitializeComponent();
        }

        private void Button_Copy_Click(object sender, RoutedEventArgs e)
        {
            int RequestId = int.Parse(txtTravelAgentReqId.Text);
            TravelRequest approve = new TravelRequest();
            BookingBL updateRequest = new BookingBL();
            bool updated = updateRequest.TicketConfirmationBL(RequestId);
            if (updated)
            {
                MessageBox.Show("Ticket Confirmed");
            }
            else
            {
                MessageBox.Show("Not Found");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int RequestId = int.Parse(txtTravelAgentReqId.Text);
                TravelRequest reject = new TravelRequest();
                BookingBL updateRequest = new BookingBL();
                bool updated = updateRequest.TicketRejectedBL(RequestId);
                if (updated)
                {
                    MessageBox.Show("No tickets Avaliable");
                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }

            catch (EmployeeTravelBookingException)
            {

                throw;
            }
            
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                TravelRequest display = new TravelRequest();
                BookingBL displayRequest = new BookingBL();
                DataTable dt = displayRequest.DisplayRequestForAgentBL();
                if (dt != null)
                {
                    dgTravelAgentDisplay.ItemsSource = dt.DefaultView;
                }
                else
                {
                    MessageBox.Show("No requests");
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                throw ex;
            }
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                TravelRequest display = new TravelRequest();
                BookingBL displayRequest = new BookingBL();
                DataTable dt = displayRequest.DisplayPreviousRequestForAgentBL();
                if (dt != null)
                {
                    dgTravelAgentDisplay.ItemsSource = dt.DefaultView;
                }
               
            }
            catch (EmployeeTravelBookingException ex)
            {

                throw ex;
            }
        }
    }
}
