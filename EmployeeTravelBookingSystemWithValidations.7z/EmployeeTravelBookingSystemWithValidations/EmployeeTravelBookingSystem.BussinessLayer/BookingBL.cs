﻿using EmployeeTravelBookingSystem.DataAccessLayer;
using EmployeeTravelBookingSystem.Exception;
using Entity;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;

namespace EmployeeTravelBookingSystem.BussinessLayer
{
    public class BookingBL
    {

        StringBuilder sb = new StringBuilder();

        public bool AddEmployee(EmployeeDetails details)
        {
            bool addEmployee = false;
            try
            {
                bool v = validateDetails(details);
                if (v)
                {
                    BookingDAL booking = new BookingDAL();
                    addEmployee = booking.AddEmployeeDAL(details);

                    if (addEmployee)
                    {
                        return true;
                    }
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return addEmployee;
        }


        public bool DeleteEmployee(int delemp)
        {
            bool deleEmployee = false;

            try
            {
                bool v = ValidateId(delemp);
                if (v)
                {
                    BookingDAL booking = new BookingDAL();
                    deleEmployee = booking.DeleteEmployeeDAL(delemp);

                    if (deleEmployee)
                    {
                        return true;
                    }
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

            return deleEmployee;
        }


        public bool TicketConfirmationBL(int requestId)
        {
            bool TicketConfirmed = false;
            try
            {
                bool v = ValidateId(requestId);
                if (v)
                {
                    BookingDAL updateRequest = new BookingDAL();
                    TicketConfirmed = updateRequest.TicketConfirmationDAL(requestId);
                    if (TicketConfirmed)
                    {
                        return true;
                    }
                }
                    
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return TicketConfirmed;
        }


        public bool TicketRejectedBL(int requestId)
        {
            bool TicketRejected = false;
            try
            {
                bool v = ValidateId(requestId);
                if (v)
                {
                    BookingDAL updateRequest = new BookingDAL();
                    TicketRejected = updateRequest.TicketRejectedDAL(requestId);
                    if (TicketRejected)
                    {
                        return true;
                    }
                }
                    
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return TicketRejected;
        }


        //Need Correction
        public DataTable DisplayManagerRequestBL(int mid)
        {
            try
            {
                bool v = ValidateId(mid);
                if (v)
                {
                    BookingDAL display = new BookingDAL();
                    return display.displayManagerRequestDAL(mid);
                }

                    
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return null;
        }


        public DataTable DisplayRequestForAgentBL()
        {
            try
            {
                BookingDAL display = new BookingDAL();
                return display.DisplayRequestForAgentDAL();
            }
            catch (EmployeeTravelBookingException )
            {

                throw;
            }
           
        }

       
        public bool UpdateManager(EmployeeDetails details)
        {
            bool Assigned = false;
            try
            {
                bool v = ValidateAssigningManagerDetails(details);
                if(v)
                {
                    BookingDAL booking = new BookingDAL();
                    Assigned = booking.UpdateManagerDAL(details);

                    if (Assigned)
                    {
                        return true;
                    }
                }
                
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return Assigned;

        }

        public bool AddAgent(TravelAgentDetails agentDetails)
        {
            bool addAgent = false;
            try
            {
                bool v = ValidateAgent(agentDetails);
                if (v)
                {

                    BookingDAL booking = new BookingDAL();
                    addAgent = booking.AddAgentDAL(agentDetails);

                    if (addAgent)
                    {
                        return true;
                    }
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
            return addAgent;
        }



        public bool AddTicketRequest(TravelRequest raiseTicket)
        {
            bool addRequest = false;
            try
            {
                bool validate = ValidateRequestDetails(raiseTicket);
                if (validate)
                {
                    BookingDAL booking = new BookingDAL();
                    addRequest = booking.AddTicketDAL(raiseTicket);

                    if (addRequest)
                    {
                        return true;
                    }
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

            return addRequest;
        }

        public bool CancelticketBL(int requestid)
        {
            bool cancelRequest = false;
            try
            {
                bool v = ValidateId(requestid);
                if (v)
                {
                    BookingDAL booking = new BookingDAL();
                    cancelRequest = booking.CancelTicketDAL(requestid);

                    if (cancelRequest)
                    {
                        return true;
                    }
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return cancelRequest;
        }

        public bool ApproveRequestBL(int eid)
        {
            bool approved = false;
            try
            {
                bool v = ValidateId(eid);
                if(v)
                {
                    BookingDAL updateRequest1 = new BookingDAL();
                    approved = updateRequest1.ApproveRequestDAL(eid);
                    if (approved)
                    {
                        return true;
                    }
                }
                //BookingDAL updateRequest = new BookingDAL();
                //approved = updateRequest.ApproveRequestDAL(eid);
                //if (approved)
                //{
                //    return true;
                //}
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return approved;
        }

        public DataTable DisplayEmpRequestBL(int eid)
        {
            DataTable dt = null;
            try
            {
                bool v = ValidateId(eid);
                
              
                if (v)
                {
                    BookingDAL display = new BookingDAL();
                    dt = display.displayEmpRequestDAL(eid);
                }

               
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return dt;

        }

        public bool RejectRequestBL(int eid)
        {
            bool rejected = false;
            try
            {
                bool v = ValidateId(eid);
                if(v)
                {
                    BookingDAL updateRequest = new BookingDAL();
                    rejected = updateRequest.RejectRequestDAL(eid);
                    if (rejected)
                    {
                        return true;
                    }
                }
                
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return rejected;
        }

        public DataTable GetMangerListBL()
        {
            try
            {
                BookingDAL booking = new BookingDAL();
                return booking.GetMangerListDAL();
            }
            catch (EmployeeTravelBookingException )
            {

                throw;
            }

           
        }



        public bool validateDetails(EmployeeDetails details)
        {
            Regex email = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Regex Mobile = new Regex(@"^[7-9]{1}[0-9]{9}$");
            Regex password = new Regex(@"^(?=[^\d_].*?\d)\w(\w|[!@#$%]){7,20}");
            Regex usern = new Regex(@"^(?=.*\d).{4,20}$");

            bool valid = true;
            if (details.EmployeeId < 100000 || details.EmployeeId > 200000 || details.EmployeeId <=0)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nEmployee should be of 6 digits between 100000 and 200000");
            }


            if (details.FirstName == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nFirst Name Cannot be Empty");
            }
            if (details.LastName == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nLast Name Cannot be Empty");
            }
            if (details.Age < 20 && details.Age > 60)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nAge ranges in 20 to 60");
            }
            if (details.Gender == null)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nYou have to select Gender");
            }
            if (details.Address == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nEnter the Address");
            }
            if (!Mobile.IsMatch(details.MobileNumber))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nPhone number is not in proper format\nStarts with 7,8,9 only");
            }
            if (details.EmailId == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nEnter Email");
            }
            else if (!email.IsMatch(details.EmailId))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nEmail id not in correct format\n eg. abc@xyz.com");
            }
            if (details.UserName == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nEnter Username");
            }
            else if (!usern.IsMatch(details.UserName))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nEnter Username . Must be between 4 and 20 digits long and include at least one numeric digit. \n eg. abcd123, abcd");
            }
            if (details.Password == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nPaasword field cannot be Empty");
            }
            else if (!password.IsMatch(details.Password))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\npassword should have length of 8 to 20 aplhanumeric characters and select special characters. The password also can not start with a digit, underscore or special character and must contain at least one digit.\n eg. password1 ");
            }

            if (details.ManagerId <= 0 || details.ManagerId < 200000 || details.ManagerId > 300000)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Select Manager");
            }
            if (valid == false)
                throw new EmployeeTravelBookingException(sb.ToString());


            return valid;


        }


        public bool ValidateRequestDetails(TravelRequest raiseTicket)
        {
            bool valid = true;

            if (raiseTicket.RequestDate == null)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nSelect Date");
            }
            else if (raiseTicket.RequestDate < DateTime.Now)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nSelected date should be after date or current date ");
            }

            if (raiseTicket.FromLocation == "" || raiseTicket.FromLocation == null)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nSelect Source Location");
            }
            if (raiseTicket.ToLocation == "" || raiseTicket.ToLocation == null)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nSelect Destination Location");
            }

            

            if (raiseTicket.ManagerId < 200000 || raiseTicket.ManagerId > 300000)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nManager id should be of 6 digits between 200000 and 300000");
            }

            if (valid == false)
                throw new EmployeeTravelBookingException(sb.ToString());

            return valid;
        }


        public bool ValidateAgent(TravelAgentDetails agentDetails)
        {
            bool validate = true;
            Regex usern = new Regex(@"^(?=.*\d).{4,20}$");
            Regex password = new Regex(@"^(?=[^\d_].*?\d)\w(\w|[!@#$%]){7,20}");

            if (agentDetails.agentName == null || agentDetails.agentName == "")
            {
                validate = false;
                sb.Append(Environment.NewLine + "\nEnter Agent Name");
            }
            if (agentDetails.agentUsername == null || agentDetails.agentUsername == "")
            {
                validate = false;
                sb.Append(Environment.NewLine + "\nEnter Username");
            }
            else if (!usern.IsMatch(agentDetails.agentUsername))
            {
                validate = false;
                sb.Append(Environment.NewLine + "\nEnter Username . Must be between 4 and 20 digits long and include at least one numeric digit. \n eg. abcd123, abcd");

            }

            if (agentDetails.agentPassword == "")
            {
                validate = false;
                sb.Append(Environment.NewLine + "\nPaasword field cannot be Empty");
            }
            else if (!password.IsMatch(agentDetails.agentPassword))
            {
                validate = false;
                sb.Append(Environment.NewLine + "\npassword should have length of 8 to 20 aplhanumeric characters and select special characters. The password also can not start with a digit, underscore or special character and must contain at least one digit.\n eg. password1 ");
            }
            if (validate == false)
                throw new EmployeeTravelBookingException(sb.ToString());

            return validate;
        }


        public bool ValidateId(int Id)
        {
            bool validate = true;

            if (Id <= 0 && Id < 200000 || Id > 300000)
            {
                validate = false;
                sb.Append(Environment.NewLine + "Enter Proper ID");
            }
            if (validate == false)
                throw new EmployeeTravelBookingException(sb.ToString());
            return validate;
        }

        public bool ValidateAssigningManagerDetails(EmployeeDetails details)
        {
            bool validate = true;

            if (details.EmployeeId < 100000 || details.EmployeeId > 200000)
            {
                validate = false;
                sb.Append(Environment.NewLine + "\nEmployee id should be of 6 digits between 100000 and 200000");
            }
            if (details.ManagerId <= 0 || details.ManagerId < 200000 || details.ManagerId > 300000)
            {
                validate = false;
                sb.Append(Environment.NewLine + "Select Manager");
            }
            if (validate == false)
                throw new EmployeeTravelBookingException(sb.ToString());
            return validate;
        }
    }
}