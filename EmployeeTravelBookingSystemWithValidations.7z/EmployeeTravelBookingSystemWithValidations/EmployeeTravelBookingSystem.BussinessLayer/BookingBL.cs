﻿using EmployeeTravelBookingSystem.DataAccessLayer;
using EmployeeTravelBookingSystem.Exception;
using Entity;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;

namespace EmployeeTravelBookingSystem.BussinessLayer
{
    public class BookingBL
    {

        StringBuilder sb = new StringBuilder();

        //Linking DAL of Adding Employee with the BL
        public bool AddEmployee(EmployeeDetails details)
        {
            bool addEmployee = false;
            try
            {
                bool v = validateDetails(details);
                if (v)
                {
                    BookingDAL booking = new BookingDAL();
                    addEmployee = booking.AddEmployeeDAL(details);

                    if (addEmployee)
                    {
                        return true;
                    }
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return addEmployee;
        }

        //Linking DAL of Deleting Employee with the BL
        public bool DeleteEmployee(int delemp)
        {
            bool deleEmployee = false;

            try
            {
                bool v = ValidateId(delemp);
                if (v)
                {
                    BookingDAL booking = new BookingDAL();
                    deleEmployee = booking.DeleteEmployeeDAL(delemp);

                    if (deleEmployee)
                    {
                        return true;
                    }
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

            return deleEmployee;
        }

        //Linking DAL of Confirming Tickets with the BL
        public bool TicketConfirmationBL(int requestId)
        {
            bool TicketConfirmed = false;
            try
            {
                bool v = ValidateId(requestId);
                if (v)
                {
                    BookingDAL updateRequest = new BookingDAL();
                    TicketConfirmed = updateRequest.TicketConfirmationDAL(requestId);
                    if (TicketConfirmed)
                    {
                        return true;
                    }
                }
                    
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return TicketConfirmed;
        }

        //Linking DAL of Status of ticket booking with the BL
        public DataTable DisplayPreviousRequestForAgentBL()
        {
            try
            {
                BookingDAL display = new BookingDAL();
                return display.DisplayPreviousRequestForAgentDAL();
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
        }

        //Linking DAL of Rejection of Ticket with the BL
        public bool TicketRejectedBL(int requestId)
        {
            bool TicketRejected = false;
            try
            {
                bool v = ValidateId(requestId);
                if (v)
                {
                    BookingDAL updateRequest = new BookingDAL();
                    TicketRejected = updateRequest.TicketRejectedDAL(requestId);
                    if (TicketRejected)
                    {
                        return true;
                    }
                }
                    
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return TicketRejected;
        }


        //Linking the DAL of Status of Ticket Confirmation or Pending of Employees with the BL
        public DataTable DisplayManagerRequestBL(int mid)
        {
            try
            {
                bool v = ValidateId(mid);
                if (v)
                {
                    BookingDAL display = new BookingDAL();
                    return display.displayManagerRequestDAL(mid);
                }

                    
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        //Linking the DAL of Displaying Status of Approval or Rejection by Manager with the BL
        public DataTable DisplayRequestForAgentBL()
        {
            try
            {
                BookingDAL display = new BookingDAL();
                return display.DisplayRequestForAgentDAL();
            }
            catch (EmployeeTravelBookingException )
            {

                throw;
            }
           
        }

       //Linking the DAL of Changing Manager by Admin to the BL
        public bool UpdateManager(EmployeeDetails details)
        {
            bool Assigned = false;
            try
            {
                bool v = ValidateAssigningManagerDetails(details);
                if(v)
                {
                    BookingDAL booking = new BookingDAL();
                    Assigned = booking.UpdateManagerDAL(details);

                    if (Assigned)
                    {
                        return true;
                    }
                }
                
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return Assigned;

        }

        //Linking the DAL of Adding Travel Agent by Admin to the BL
        public bool AddAgent(TravelAgentDetails agentDetails)
        {
            bool addAgent = false;
            try
            {
                bool v = ValidateAgent(agentDetails);
                if (v)
                {

                    BookingDAL booking = new BookingDAL();
                    addAgent = booking.AddAgentDAL(agentDetails);

                    if (addAgent)
                    {
                        return true;
                    }
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {

                MessageBox.Show(ex.Message);
            }
            return addAgent;
        }


        //Linking the DAL of Adding Tickets after checking the availability by Travel Agent to the BL
        public bool AddTicketRequest(TravelRequest raiseTicket)
        {
            bool addRequest = false;
            try
            {
                bool validate = ValidateRequestDetails(raiseTicket);
                if (validate)
                {
                    BookingDAL booking = new BookingDAL();
                    addRequest = booking.AddTicketDAL(raiseTicket);

                    if (addRequest)
                    {
                        return true;
                    }
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

            return addRequest;
        }

        //Linking the DAL of Cancelling Tickets by Travel Agent to the BL
        public bool CancelticketBL(int requestid)
        {
            bool cancelRequest = false;
            try
            {
                bool v = ValidateId(requestid);
                if (v)
                {
                    BookingDAL booking = new BookingDAL();
                    cancelRequest = booking.CancelTicketDAL(requestid);

                    if (cancelRequest)
                    {
                        return true;
                    }
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return cancelRequest;
        }

        //Linking the DAL of Approving Request by Manager to the BL
        public bool ApproveRequestBL(int requestId)
        {
            bool approved = false;
            try
            {
               
                    BookingDAL updateRequest1 = new BookingDAL();
                    approved = updateRequest1.ApproveRequestDAL(requestId);
                    if (approved)
                    {
                        return true;
                    }
             
               
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return approved;
        }

        //Linking the DAL of Displaying the Request List of Employees to the BL
        public DataTable DisplayEmpRequestBL(int eid)
        {
            DataTable dt = null;
            try
            {
                bool v = ValidateId(eid);
                
              
                if (v)
                {
                    BookingDAL display = new BookingDAL();
                    dt = display.displayEmpRequestDAL(eid);
                }

               
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return dt;

        }

        //Linking the DAL of Rejecting Requests by Manager to the BL
        public bool RejectRequestBL(int requestId)
        {
            bool rejected = false;
            try
            {
                bool v = ValidateId(requestId);
                if(v)
                {
                    BookingDAL updateRequest = new BookingDAL();
                    rejected = updateRequest.RejectRequestDAL(requestId);
                    if (rejected)
                    {
                        return true;
                    }
                }
                
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }

            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return rejected;
        }

        //Linking the DAL of the Manager Lists to the BL
        public DataTable GetMangerListBL()
        {
            try
            {
                BookingDAL booking = new BookingDAL();
                return booking.GetMangerListDAL();
            }
            catch (EmployeeTravelBookingException )
            {

                throw;
            } 
        }

        //Validiting the Details of Employee
        public bool validateDetails(EmployeeDetails details)
        {
            Regex email = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Regex Mobile = new Regex(@"^[7-9]{1}[0-9]{9}$");
            Regex password = new Regex(@"^(?=[^\d_].*?\d)\w(\w|[!@#$%]){7,20}");
            Regex usern = new Regex(@"^(?=.*\d).{4,20}$");

            bool valid = true;
            if (details.EmployeeId < 100000 || details.EmployeeId > 200000 || details.EmployeeId <=0)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nEmployee id should be of 6 digits between 100000 and 200000");
            }


            if (details.FirstName == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nFirst Name Cannot be Empty");
            }
            if (details.LastName == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nLast Name Cannot be Empty");
            }
            if (details.Age < 20 && details.Age > 60)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nAge ranges in 20 to 60");
            }
            if (details.Gender == null)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nYou have to select Gender");
            }
            if (details.Address == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nEnter the Address");
            }
            if (!Mobile.IsMatch(details.MobileNumber))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nPhone number is not in proper format\nStarts with 7,8,9 only");
            }
            if (details.EmailId == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nEnter Email");
            }
            else if (!email.IsMatch(details.EmailId))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nEmail id not in correct format\n eg. abc@xyz.com");
            }
            if (details.UserName == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nEnter Username");
            }
            else if (!usern.IsMatch(details.UserName))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nEnter Username . Must be between 4 and 20 digits long and include at least one numeric digit. \n eg. abcd123, abcd");
            }
            if (details.Password == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nPaasword field cannot be Empty");
            }
            else if (!password.IsMatch(details.Password))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\npassword should have length of 8 to 20 aplhanumeric characters and select special characters. The password also can not start with a digit, underscore or special character and must contain at least one digit.\n eg. password1 ");
            }

            if (details.ManagerId <= 0 || details.ManagerId < 200000 || details.ManagerId > 300000)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Select Manager");
            }
            if (valid == false)
                throw new EmployeeTravelBookingException(sb.ToString());

            return valid;
        }

        //Validating the Travel Request Details
        public bool ValidateRequestDetails(TravelRequest raiseTicket)
        {
            bool valid = true;

            if (raiseTicket.RequestDate == null)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nSelect Date");
            }
            else if (raiseTicket.RequestDate <= DateTime.Now)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nSelected date should be after date from the current date");
            }

            if (raiseTicket.FromLocation == "" )
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nSelect Source Location");
            }
            if (raiseTicket.ToLocation == "" )
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nSelect Destination Location");
            }
            else if(raiseTicket.FromLocation==raiseTicket.ToLocation)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nSelect Two Different Locations");
            }

            

            

            if (valid == false)
                throw new EmployeeTravelBookingException(sb.ToString());

            return valid;
        }

        //Validating the Travel Agent Details
        public bool ValidateAgent(TravelAgentDetails agentDetails)
        {
            bool validate = true;
            Regex usern = new Regex(@"^(?=.*\d).{4,20}$");
            Regex password = new Regex(@"^(?=[^\d_].*?\d)\w(\w|[!@#$%]){4,20}");

            if (agentDetails.agentName == null || agentDetails.agentName == "")
            {
                validate = false;
                sb.Append(Environment.NewLine + "\nEnter Agent Id");
            }
            if (agentDetails.agentUsername == null || agentDetails.agentUsername == "")
            {
                validate = false;
                sb.Append(Environment.NewLine + "\nEnter Username");
            }
            else if (!usern.IsMatch(agentDetails.agentUsername))
            {
                validate = false;
                sb.Append(Environment.NewLine + "\nEnter Username . Must be between 4 and 20 digits long and include at least one numeric digit. \n eg. abcd123, abcd");

            }

            if (agentDetails.agentPassword == "")
            {
                validate = false;
                sb.Append(Environment.NewLine + "\nPaasword field cannot be Empty");
            }
            else if (!password.IsMatch(agentDetails.agentPassword))
            {
                validate = false;
                sb.Append(Environment.NewLine + "\npassword should have length of 4 to 20 aplhanumeric characters and select special characters. The password also can not start with a digit, underscore or special character and must contain at least one digit.\n eg. password1 ");
            }
            if (validate == false)
                throw new EmployeeTravelBookingException(sb.ToString());

            return validate;
        }

        //Validating the Employee ID
        public bool ValidateId(int Id)
        {
            bool validate = true;

            if (Id <= 0 && Id < 200000 || Id > 300000)
            {
                validate = false;
                sb.Append(Environment.NewLine + "Enter Proper ID");
            }
            if (validate == false)
                throw new EmployeeTravelBookingException(sb.ToString());
            return validate;
        }

        //Validating the Deatils of Assigning of Manager
        public bool ValidateAssigningManagerDetails(EmployeeDetails details)
        {
            bool validate = true;

            if (details.EmployeeId < 100000 || details.EmployeeId > 200000)
            {
                validate = false;
                sb.Append(Environment.NewLine + "\nEmployee id should be of 6 digits between 100000 and 200000");
            }
          
            if (validate == false)
                throw new EmployeeTravelBookingException(sb.ToString());
            return validate;
        }
    }
}