﻿using Entity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EmployeeTravelBookingSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public string  pass;
        public string user;
        public string managerUser;
        public string managerPass;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            CanvasTravelAgent.Visibility = Visibility.Hidden;
            CanvasManager.Visibility = Visibility.Hidden;
            CanvasEmployee.Visibility = Visibility.Hidden;
            CanvasAdmin.Visibility = Visibility.Visible;
        }

        private void btnAdminLogin_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlcon = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString))
            {
                string query = $"select count(1) from mini.AdminLogin where AdminUsername='" + txtAdminId.Text.Trim() + "' AND AdminPass='" + txtAdminId.Text.Trim() + "'";
                SqlCommand cmd = new SqlCommand(query, sqlcon);
                sqlcon.Open();
                //cmd.Parameters.AddWithValue("@LoginId", txtAdminId.Text.Trim());
                //cmd.Parameters.AddWithValue("@Pass", txtAdminpass.Text.Trim());

                int count = Convert.ToInt32(cmd.ExecuteScalar());
                if (count == 1)
                {
                    AdminForm newWindow = new AdminForm();
                    newWindow.Show();
                }
                else
                {
                    lblAdminLogin.Content = "User not Found";
                }

            }
        }

        private void textBox_Copy_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            CanvasTravelAgent.Visibility = Visibility.Hidden;
            CanvasManager.Visibility = Visibility.Hidden;
            CanvasAdmin.Visibility = Visibility.Hidden;
            CanvasEmployee.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            CanvasTravelAgent.Visibility = Visibility.Hidden;
            CanvasEmployee.Visibility = Visibility.Hidden;
            CanvasAdmin.Visibility = Visibility.Hidden;
            CanvasManager.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            CanvasEmployee.Visibility = Visibility.Hidden;
            CanvasAdmin.Visibility = Visibility.Hidden;
            CanvasManager.Visibility = Visibility.Hidden;
            CanvasTravelAgent.Visibility = Visibility.Visible;
        }

        private void btnEmployeeLogin_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlcon = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString))
            {
                string query = $"select count(1) from mini.EmployeeDetails where username='" + txtEmployeeLogin.Text.Trim() + "' AND password='" + txtEmployeePass.Text.Trim() + "'";
                SqlCommand cmd = new SqlCommand(query, sqlcon);
                sqlcon.Open();
                //cmd.Parameters.AddWithValue("@LoginId", txtAdminId.Text.Trim());
                //cmd.Parameters.AddWithValue("@Pass", txtAdminpass.Text.Trim());
                user = txtEmployeeLogin.Text.ToString();
                pass = txtEmployeePass.Text.Trim();
                int count = Convert.ToInt32(cmd.ExecuteScalar());
                if (count == 1)
                {
                    EmployeeForm newWindow = new EmployeeForm(user, pass);
                    newWindow.Show();
                }
                else
                {
                    lblAdminLogin.Content = "User not Found";
                }

            }
        }



        private void btnManagerLogin_Click(object sender, RoutedEventArgs e)
        {
            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand($"select * from mini.ManagerLogin where Username ='" + txtManagerLogin.Text + "' and password ='" + txtManagerpass.Text + "'", con);
            con.Open();
            managerUser = txtManagerLogin.Text;
            managerPass = txtManagerpass.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                MessageBox.Show("Logged in");
                var manager = new ManagerPage(managerUser, managerPass);
                manager.Show();
            }
            else
            {
                MessageBox.Show("Invalid");
            }
        }



        private void btnTravelAgentLogin_Click(object sender, RoutedEventArgs e)
        {
            TravelAgent taf = new TravelAgent();
            taf.Show();
        }

        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {

        }
    }
}
