﻿using EmployeeTravelBookingSystem.BussinessLayer;
using Entity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeTravelBookingSystem
{
    /// <summary>
    /// Interaction logic for ManagerPage.xaml
    /// </summary>
    public partial class ManagerPage : Window
    {
        private string managerUser;
        private string managerPass;

        public ManagerPage()
        {
            InitializeComponent();
        }

        public ManagerPage(string managerUser, string managerPass)
        {
            this.managerUser = managerUser;
            this.managerPass = managerPass;
            InitializeComponent();
        }

        private void BtnManagerDisplay_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void ManagerGrid_Loaded(object sender, RoutedEventArgs e)
        {
            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "mini.getdetails";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@username", managerUser);
            cmd.Parameters.AddWithValue("@password", managerPass);

            //SqlParameter managerid = new SqlParameter("@EmployeeId", SqlDbType.Int) { Direction = ParameterDirection.Output };
            //cmd.Parameters.Add(empid);
            SqlParameter manName = new SqlParameter("@managerName", SqlDbType.VarChar, 50) { Direction = ParameterDirection.Output };
            cmd.Parameters.Add(manName);

            con.Open();

            SqlDataReader sd = cmd.ExecuteReader();

            txtManagerName.Text = manName.Value.ToString();

            
        }

        private void BtnManagerApproved_Click(object sender, RoutedEventArgs e)
        {
            int eid = int.Parse(txtManagerEmpId.Text);
            TravelRequest approve = new TravelRequest();
            BookingBL updateRequest = new BookingBL();
            bool updated = updateRequest.ApproveRequestBL(eid);
            if (updated)
            {
                MessageBox.Show("Approved");
            }
            else
            {
                MessageBox.Show("Not Found");
            }

        }

        private void BtnManagerCancel_Click(object sender, RoutedEventArgs e)
        {
            int eid = int.Parse(txtManagerEmpId.Text);
            TravelRequest approve = new TravelRequest();
            BookingBL updateRequest = new BookingBL();
            bool updated = updateRequest.RejectRequestBL(eid);
            if (updated)
            {
                MessageBox.Show("Rejected");
            }
            else
            {
                MessageBox.Show("Not Found");
            }
        }
    }
}
