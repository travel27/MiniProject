﻿using EmployeeTravelBookingSystem.BussinessLayer;
using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeTravelBookingSystem
{
    /// <summary>
    /// Interaction logic for AdminForm.xaml
    /// </summary>
    public partial class AdminForm : Window
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            CanvasAddTravelAgent.Visibility = Visibility.Hidden;
            CanvasAssignManager.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            CanvasAddTravelAgent.Visibility = Visibility.Hidden;
            CanvasAssignManager.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            CanvasAddTravelAgent.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Hidden;
            CanvasAssignManager.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            CanvasAssignManager.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Hidden;
            CanvasAddTravelAgent.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {

        }

        private void BtnAddEmployee_Click(object sender, RoutedEventArgs e)
        {
            string gender;
            if (rbtnAddEmployeeMale.IsChecked == true)
            {
                gender = "Male";
            }
            else
            {
                gender = "Female";
            }
            EmployeeDetails details = new EmployeeDetails()
            {
                EmployeeId = int.Parse(txtAddEmployeeEmpId.Text),
                FirstName = txtAddEmployeeFname.Text,
                LastName = txtAddEmployeeLname.Text,
                Age = int.Parse(txtAddEmployeeAge.Text),
                Gender = gender,
                Address = txtEmployeeAddress.Text,
                MobileNumber = txtEmployeeMobilenumber.Text,
                EmailId = txtEmployeeEmailId.Text,
                UserName = txtAddEmployeeUserId.Text,
                Password = txtAddEmployeePassword.Text,
                ManagerId = cmbBoxManagerId.SelectedIndex.ToString()
                
                
            };
            BookingBL bbl = new BookingBL();
            bool employeeAdded=bbl.AddEmployee(details);
            if (employeeAdded)
            {
                MessageBox.Show("Employee Added");
            }
            else
            {
                MessageBox.Show("Employee not Found");
            }
        }
        enum ManagerId
        {
            John=100001,
            Paul= 100002,
            Priya=100003,
            Riya=1000004
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void CanvasAddEmployee_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (var item in Enum.GetValues(typeof(ManagerId)))
            {
                cmbBoxManagerId.Items.Add(item);
            }
        }

        private void BtnDeleteEmployee_Click(object sender, RoutedEventArgs e)
        {
            
            int delemp = int.Parse(txtDeleteEmployeeId.Text);
            BookingBL bbl = new BookingBL();
           bool deleteEmployee=  bbl.DeleteEmployee(delemp);
            if (deleteEmployee)
            {
                MessageBox.Show("employee deleted");
            }
            else
            {
                MessageBox.Show("Employee Not Found");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            EmployeeDetails details = new EmployeeDetails()
            {
                EmployeeId =Convert.ToInt32(txtEmployeeIdForAssigningManager.Text),
                ManagerId = cbAssignMangerName.SelectedIndex.ToString()
            };
            //string mname = cbAssignMangerName.SelectedIndex.ToString();
            //int eid = int.Parse(txtAddEmployeeEmpId.Text.ToString());

            BookingBL bbl = new BookingBL();
            bool Assigned = bbl.UpdateManager(details);
            if (Assigned)
            {
                MessageBox.Show("Manager Assigned");
            }
            else
            {
                MessageBox.Show("Employee not Found");
            }
        }

        private void CanvasAssignManager_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (var item in Enum.GetValues(typeof(ManagerId)))
            {
                cbAssignMangerName.Items.Add(item);
            }
        }

        private void BtnAddAgent_Click(object sender, RoutedEventArgs e)
        {
            TravelAgentDetails agentDetails = new TravelAgentDetails() {
                agentName = txtAddAgentName.Text,
                agentUsername = txtAddAgentUserName.Text,
                agentPassword = txtAddAgentPass.Text
           
            };

            BookingBL agent = new BookingBL();
            bool addAgent = agent.AddAgent(agentDetails);
            if (addAgent)
            {
                MessageBox.Show("Agent Added");
            }
            else
            {
                MessageBox.Show("Agent not Added");
            }

        }
    }
    
}
