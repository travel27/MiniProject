﻿using EmployeeTravelBookingSystem.BussinessLayer;
using EmployeeTravelBookingSystem.Exception;
using Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeTravelBookingSystem
{
    /// <summary>
    /// Interaction logic for AdminForm.xaml
    /// </summary>
    public partial class AdminForm : Window
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            CanvasAddTravelAgent.Visibility = Visibility.Hidden;
            CanvasAssignManager.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            CanvasAddTravelAgent.Visibility = Visibility.Hidden;
            CanvasAssignManager.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            CanvasAddTravelAgent.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Hidden;
            CanvasAssignManager.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            CanvasAssignManager.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Hidden;
            CanvasAddTravelAgent.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {

        }

        private void BtnAddEmployee_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string gender;
                if (rbtnAddEmployeeMale.IsChecked == true)
                {
                    gender = "Male";
                }
                else
                {
                    gender = "Female";
                }
                EmployeeDetails details = new EmployeeDetails()
                {
                    EmployeeId = int.Parse(txtAddEmployeeEmpId.Text),
                    FirstName = txtAddEmployeeFname.Text,
                    LastName = txtAddEmployeeLname.Text,
                    Age = int.Parse(txtAddEmployeeAge.Text),
                    Gender = gender,
                    Address = txtEmployeeAddress.Text,
                    MobileNumber = txtEmployeeMobilenumber.Text,
                    EmailId = txtEmployeeEmailId.Text,
                    UserName = txtAddEmployeeUserId.Text,
                    Password = txtAddEmployeePassword.Text,
                    ManagerId = int.Parse(comboBoxForManager.SelectedValue.ToString())


                };
                BookingBL bbl = new BookingBL();
                bool employeeAdded = bbl.AddEmployee(details);
                if (employeeAdded)
                {
                    MessageBox.Show("Employee Added");
                    txtAddEmployeeEmpId.Text = " ";
                    txtAddEmployeeFname.Text = " ";
                    txtAddEmployeeLname.Text = " ";
                    txtAddEmployeeAge.Text = " ";
                    txtEmployeeAddress.Text = " ";
                    txtEmployeeMobilenumber.Text = " ";
                    txtEmployeeEmailId.Text = " ";
                    txtAddEmployeeUserId.Text = " ";
                    txtAddEmployeePassword.Text = " ";


                }
                else
                {
                    MessageBox.Show("Employee not Found");
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
        }
       

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void CanvasAddEmployee_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {

                BookingBL pb = new BookingBL();
                DataTable dt = pb.GetMangerListBL();
                if (dt != null)
                {
                    comboBoxForManager.ItemsSource = dt.DefaultView;
                    comboBoxForManager.DisplayMemberPath = "ManagerName";
                    comboBoxForManager.SelectedValuePath = "ManagerId";
                }
                else
                {
                    MessageBox.Show("Table is empty");
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
        }

        private void BtnDeleteEmployee_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                int delemp = int.Parse(txtDeleteEmployeeId.Text);
                BookingBL bbl = new BookingBL();
                bool deleteEmployee = bbl.DeleteEmployee(delemp);
                if (deleteEmployee)
                {
                    MessageBox.Show("employee deleted");
                    txtDeleteEmployeeId.Text = " ";
                }
                else
                {
                    MessageBox.Show("Employee Not Found");
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                EmployeeDetails details = new EmployeeDetails()
                {
                    EmployeeId = Convert.ToInt32(txtEmployeeIdForAssigningManager.Text),
                    ManagerId = int.Parse(cbAssignMangerName.SelectedValue.ToString())
                };


                BookingBL bbl = new BookingBL();
                bool Assigned = bbl.UpdateManager(details);
                if (Assigned)
                {
                    MessageBox.Show("Manager Assigned");
                    txtEmployeeIdForAssigningManager.Text = " ";
                }
                else
                {
                    MessageBox.Show("Manager not found");
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
        }

        private void CanvasAssignManager_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {

                BookingBL pb = new BookingBL();
                DataTable dt = pb.GetMangerListBL();
                if (dt != null)
                {
                    cbAssignMangerName.ItemsSource = dt.DefaultView;
                    cbAssignMangerName.DisplayMemberPath = "ManagerName";
                    cbAssignMangerName.SelectedValuePath = "ManagerId";
                }
                else
                {
                    MessageBox.Show("Table is empty");
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
          
        }

        private void BtnAddAgent_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                TravelAgentDetails agentDetails = new TravelAgentDetails()
                {
                    agentName = txtAddAgentName.Text,
                    agentUsername = txtAddAgentUserName.Text,
                    agentPassword = txtAddAgentPass.Text

                };

                BookingBL agent = new BookingBL();
                bool addAgent = agent.AddAgent(agentDetails);
                if (addAgent)
                {
                    MessageBox.Show("Agent Added");
                    txtAddAgentName.Text = " ";
                    txtAddAgentUserName.Text = " ";
                    txtAddAgentPass.Text = " ";
                }
                else
                {
                    MessageBox.Show("Agent not Added");
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }

        }
    }
    
}
