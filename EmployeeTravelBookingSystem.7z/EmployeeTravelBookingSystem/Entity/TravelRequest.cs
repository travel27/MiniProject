﻿using System;
using System.Data;

namespace Entity
{
    public class TravelRequest
    {

        public int RequestId { get; set; }
        public DateTime RequestDate { get; set; }
        public string FromLocation { get; set; }
        public string ToLocation { get; set; }
        public int EmployeeId { get; set; }
        public string ManagerId { get; set; }
        public string Status { get; set; }
    }

}