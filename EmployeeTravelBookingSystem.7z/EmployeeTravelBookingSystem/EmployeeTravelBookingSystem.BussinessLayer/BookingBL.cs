﻿using EmployeeTravelBookingSystem.DataAccessLayer;
using Entity;
using System;
using System.Data;

namespace EmployeeTravelBookingSystem.BussinessLayer
{
    public class BookingBL
    {
        public bool AddEmployee(EmployeeDetails details)
        {
            bool addEmployee = false;
            BookingDAL booking = new BookingDAL();
            addEmployee = booking.AddEmployeeDAL(details);

            if (addEmployee)
            {
                return true;
            }
            return addEmployee;
        }




        public bool DeleteEmployee(int delemp)
        {
            bool deleEmployee = false;
           
            BookingDAL booking = new BookingDAL();
            deleEmployee = booking.DeleteEmployeeDAL(delemp);

            if (deleEmployee)
            {
                return true;
            }
            return deleEmployee;
        }

        public bool TicketConfirmationBL(int requestId)
        {
            bool TicketConfirmed = false;
            BookingDAL updateRequest = new BookingDAL();
            TicketConfirmed = updateRequest.TicketConfirmationDAL(requestId);
            if (TicketConfirmed)
            {
                return true;
            }
            return TicketConfirmed;
        }

        public bool TicketRejectedBL(int requestId)
        {
            bool TicketRejected = false;
            BookingDAL updateRequest = new BookingDAL();
            TicketRejected = updateRequest.TicketRejectedDAL(requestId);
            if (TicketRejected)
            {
                return true;
            }
            return TicketRejected;
        }

        public DataTable DisplayRequestForAgentBL()
        {
            BookingDAL display = new BookingDAL();
            return display.DisplayRequestForAgentDAL();
        }

        //public bool UpdateManager(int eid, string mname)
        //{
        //    bool Assigned = false;
        //    BookingDAL booking = new BookingDAL();
        //    Assigned = booking.UpdateManagerDAL(eid,mname);

        //    if (Assigned)
        //    {
        //        return true;
        //    }
        //    return Assigned;
        //}



        public bool UpdateManager(EmployeeDetails details)
        {
            bool Assigned = false;
            BookingDAL booking = new BookingDAL();
            Assigned = booking.UpdateManagerDAL(details);

            if (Assigned)
            {
                return true;
            }
            return Assigned;

        }

        public bool AddAgent(TravelAgentDetails agentDetails)
        {
            bool addAgent = false;
            BookingDAL booking = new BookingDAL();
            addAgent = booking.AddAgentDAL(agentDetails);

            if (addAgent)
            {
                return true;
            }
            return addAgent;
        }



        public bool AddTicketRequest(TravelRequest raiseTicket)
        {
            bool addRequest = false;
            BookingDAL booking = new BookingDAL();
            addRequest = booking.AddTicketDAL(raiseTicket);

            if (addRequest)
            {
                return true;
            }
            return addRequest;
        }

        public bool CancelticketBL(int requestid)
        {
            bool cancelRequest = false;
            BookingDAL booking = new BookingDAL();
            cancelRequest = booking.CancelTicketDAL(requestid);

            if (cancelRequest)
            {
                return true;
            }
            return cancelRequest;
        }

        public bool ApproveRequestBL(int eid)
        {
            bool approved = false;
            BookingDAL updateRequest = new BookingDAL();
            approved = updateRequest.ApproveRequestDAL(eid);
            if (approved)
            {
                return true;
            }
            return approved;
        }

        public DataTable DisplayEmpRequestBL(int eid)
        {
            //bool displayRequest = false;
            BookingDAL display = new BookingDAL();
           return display.displayEmpRequestDAL(eid);
            
        }

        public bool RejectRequestBL(int eid)
        {
            bool rejected = false;
            BookingDAL updateRequest = new BookingDAL();
            rejected = updateRequest.RejectRequestDAL(eid);
            if (rejected)
            {
                return true;
            }
            return rejected;
        }
    }
}