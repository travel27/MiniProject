﻿using EmployeeTravelBookingSystem.DataAccessLayer;
using EmployeeTravelBookingSystem.Exception;
using Entity;
using System;
using System.Data;

namespace EmployeeTravelBookingSystem.BussinessLayer
{
    public class BookingBL
    {
        public bool AddEmployee(EmployeeDetails details)
        {
            bool addEmployee = false;
            try
            {
                BookingDAL booking = new BookingDAL();
                addEmployee = booking.AddEmployeeDAL(details);

                if (addEmployee)
                {
                    return true;
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
            return addEmployee;
        }




        public bool DeleteEmployee(int delemp)
        {
            bool deleEmployee = false;

            try
            {
                BookingDAL booking = new BookingDAL();
                deleEmployee = booking.DeleteEmployeeDAL(delemp);

                if (deleEmployee)
                {
                    return true;
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
            
            return deleEmployee;
        }

        public bool TicketConfirmationBL(int requestId)
        {
            bool TicketConfirmed = false;
            try
            {
                BookingDAL updateRequest = new BookingDAL();
                TicketConfirmed = updateRequest.TicketConfirmationDAL(requestId);
                if (TicketConfirmed)
                {
                    return true;
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
            return TicketConfirmed;
        }

        public bool TicketRejectedBL(int requestId)
        {
            bool TicketRejected = false;
            try
            {
                BookingDAL updateRequest = new BookingDAL();
                TicketRejected = updateRequest.TicketRejectedDAL(requestId);
                if (TicketRejected)
                {
                    return true;
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
            return TicketRejected;
        }

        public DataTable DisplayManagerRequestBL(int mid)
        {
            try
            {
                BookingDAL display = new BookingDAL();
                return display.displayManagerRequestDAL(mid);
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
        }

        public DataTable DisplayRequestForAgentBL()
        {
            try
            {
                BookingDAL display = new BookingDAL();
                return display.DisplayRequestForAgentDAL();
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
        }

       



        public bool UpdateManager(EmployeeDetails details)
        {
            bool Assigned = false;
            try
            {
                BookingDAL booking = new BookingDAL();
                Assigned = booking.UpdateManagerDAL(details);

                if (Assigned)
                {
                    return true;
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
            return Assigned;

        }

        public bool AddAgent(TravelAgentDetails agentDetails)
        {
            bool addAgent = false;
            try
            {
                BookingDAL booking = new BookingDAL();
                addAgent = booking.AddAgentDAL(agentDetails);

                if (addAgent)
                {
                    return true;
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
            return addAgent;
        }



        public bool AddTicketRequest(TravelRequest raiseTicket)
        {
            bool addRequest = false;
            try
            {
                BookingDAL booking = new BookingDAL();
                addRequest = booking.AddTicketDAL(raiseTicket);

                if (addRequest)
                {
                    return true;
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
            return addRequest;
        }

        public bool CancelticketBL(int requestid)
        {
            bool cancelRequest = false;
            try
            {
                BookingDAL booking = new BookingDAL();
                cancelRequest = booking.CancelTicketDAL(requestid);

                if (cancelRequest)
                {
                    return true;
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
            return cancelRequest;
        }

        public bool ApproveRequestBL(int eid)
        {
            bool approved = false;
            try
            {
                BookingDAL updateRequest = new BookingDAL();
                approved = updateRequest.ApproveRequestDAL(eid);
                if (approved)
                {
                    return true;
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
            return approved;
        }

        public DataTable DisplayEmpRequestBL(int eid)
        {

            try
            {
                BookingDAL display = new BookingDAL();
                return display.displayEmpRequestDAL(eid);
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
            
        }

        public bool RejectRequestBL(int eid)
        {
            bool rejected = false;
            try
            {
                BookingDAL updateRequest = new BookingDAL();
                rejected = updateRequest.RejectRequestDAL(eid);
                if (rejected)
                {
                    return true;
                }
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
            return rejected;
        }

        public DataTable GetMangerListBL()
        {
            try
            {
                BookingDAL booking = new BookingDAL();
                return booking.GetMangerListDAL();
            }
            catch (EmployeeTravelBookingException)
            {

                throw;
            }
        }
    }
}